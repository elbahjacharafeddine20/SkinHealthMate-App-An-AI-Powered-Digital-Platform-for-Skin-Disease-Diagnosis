export const themeColors = {
    bg: '#877dfa',
}