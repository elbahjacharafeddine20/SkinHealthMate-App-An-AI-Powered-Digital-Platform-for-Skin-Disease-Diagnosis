// apiConfig.js

// export const API_BASE_URL   = 'http://192.168.137.1:8080';
// export const API_BASE_URL   = 'http://13.48.10.141';
export const API_BASE_URL   = 'http://10.0.2.2:8080';

export const API_BASE_MODEL = 'http://10.0.2.2:5000';
// export const API_BASE_MODEL = 'http://16.171.39.179';
// export const API_BASE_MODEL = 'http://127.0.0.1:5000';

