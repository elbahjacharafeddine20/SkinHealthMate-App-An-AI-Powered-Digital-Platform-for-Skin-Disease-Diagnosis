import { View, Text } from 'react-native'
import React from 'react'

export default function Backups() {
  return (
    <View style={{flex: 1, alignItems: "center", justifyContent: "center"}}>
      <Text>Backups</Text>
    </View>
  )
}